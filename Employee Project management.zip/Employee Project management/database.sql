-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- المزود: localhost
-- أنشئ في: 10 نوفمبر 2022 الساعة 14:22
-- إصدارة المزود: 5.5.8
--  PHP إصدارة: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `ourproject`
--

-- --------------------------------------------------------

--
-- بنية الجدول `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `deptno` int(4) NOT NULL,
  `deptname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  PRIMARY KEY (`deptno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `department`
--

INSERT INTO `department` (`deptno`, `deptname`, `location`) VALUES
(1, 'Accounting', 'asbahi'),
(3, 'it', 'hadda'),
(4, 'fiancec managmant', 'asbahi'),
(5, 'manufactor', 'hadda'),
(6, 'customer service', 'asbahi');

-- --------------------------------------------------------

--
-- بنية الجدول `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `empno` int(4) NOT NULL,
  `empname` varchar(50) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `salary` double NOT NULL,
  `hiringdate` varchar(50) NOT NULL,
  `emptype` varchar(50) NOT NULL,
  `adderss` varchar(50) NOT NULL,
  `deptno` int(4) NOT NULL,
  PRIMARY KEY (`empno`),
  KEY `deptno` (`deptno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `employee`
--


-- --------------------------------------------------------

--
-- بنية الجدول `employeeh`
--

CREATE TABLE IF NOT EXISTS `employeeh` (
  `empno` int(11) NOT NULL,
  `empname` varchar(50) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `salary` double NOT NULL,
  `hiringdate` varchar(50) NOT NULL,
  `emptype` varchar(50) NOT NULL,
  `hours` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `deptno` int(11) NOT NULL,
  PRIMARY KEY (`empno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `employeeh`
--

INSERT INTO `employeeh` (`empno`, `empname`, `birthdate`, `salary`, `hiringdate`, `emptype`, `hours`, `address`, `deptno`) VALUES
(1, 'ali', '1988/9/9', 20, '2000/1/9', 'Hourly', 5, 'ourproject.Address@1f92cc8', 2),
(2, 'mohammed', '1998/1/9', 50, '2000/1/1', 'Hourly', 8, 'ourproject.Address@1f92cc8', 2),
(3, 'mariam', '1987/1/9', 60, '2004/1/9', 'Hourly', 7, 'ourproject.Address@1f92cc8', 2);

-- --------------------------------------------------------

--
-- بنية الجدول `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `empno` int(11) NOT NULL,
  `empname` varchar(50) NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `hiringdate` varchar(50) NOT NULL,
  `emptype` varchar(50) NOT NULL,
  `vacations` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `deptno` int(11) NOT NULL,
  PRIMARY KEY (`empno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `employees`
--

INSERT INTO `employees` (`empno`, `empname`, `birthdate`, `salary`, `hiringdate`, `emptype`, `vacations`, `address`, `deptno`) VALUES
(1, 'hanan', '2000/1/1', '500.0', '2021/1/9', 'Salaried', '5', 'ourproject.Address@98d449', 2),
(3, 'tasneem', '2002/1/9', '8000.0', '2021/1/9', 'Salaried', '8', 'ourproject.Address@98d449', 2);

-- --------------------------------------------------------

--
-- بنية الجدول `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `projectno` int(4) NOT NULL,
  `projectname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `deptno` int(4) NOT NULL,
  PRIMARY KEY (`projectno`),
  KEY `fk_pro_dept` (`deptno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `project`
--

INSERT INTO `project` (`projectno`, `projectname`, `location`, `deptno`) VALUES
(1, 'accounting system', 'hadda', 1),
(2, 'marketing for products', 'asbahi', 6),
(3, 'client needs', 'asbahi', 6),
(4, 're_deploying human source', 'asbahi', 4),
(5, 'yy', 'yyyy', 3);

-- --------------------------------------------------------

--
-- بنية الجدول `workon`
--

CREATE TABLE IF NOT EXISTS `workon` (
  `empno` int(4) NOT NULL,
  `projectno` int(4) NOT NULL,
  KEY `empno` (`empno`),
  KEY `projectno` (`projectno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `workon`
--


-- --------------------------------------------------------

--
-- بنية الجدول `workonh`
--

CREATE TABLE IF NOT EXISTS `workonh` (
  `projectno` int(11) NOT NULL,
  `empno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `workonh`
--

INSERT INTO `workonh` (`projectno`, `empno`) VALUES
(3, 4),
(2, 1),
(2, 3);

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`deptno`) REFERENCES `department` (`deptno`);

--
-- القيود للجدول `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `fk_pro_dept` FOREIGN KEY (`deptno`) REFERENCES `department` (`deptno`),
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`deptno`) REFERENCES `department` (`deptno`);

--
-- القيود للجدول `workon`
--
ALTER TABLE `workon`
  ADD CONSTRAINT `workon_ibfk_10` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`),
  ADD CONSTRAINT `workon_ibfk_1` FOREIGN KEY (`empno`) REFERENCES `employee` (`empno`),
  ADD CONSTRAINT `workon_ibfk_2` FOREIGN KEY (`projectno`) REFERENCES `project` (`projectno`),
  ADD CONSTRAINT `workon_ibfk_3` FOREIGN KEY (`empno`) REFERENCES `employeeh` (`empno`),
  ADD CONSTRAINT `workon_ibfk_4` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`),
  ADD CONSTRAINT `workon_ibfk_5` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`),
  ADD CONSTRAINT `workon_ibfk_6` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`),
  ADD CONSTRAINT `workon_ibfk_7` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`),
  ADD CONSTRAINT `workon_ibfk_8` FOREIGN KEY (`projectno`) REFERENCES `project` (`projectno`),
  ADD CONSTRAINT `workon_ibfk_9` FOREIGN KEY (`empno`) REFERENCES `employees` (`empno`);
