
package ourproject;

import javax.swing.JTable;

public interface MainData {
    // 9 methods 
    // Ebtehal Taqwa 
    // add update delete getAutoNumber getAllRows getOneRow
    // hesham ali youmna mohammed ebtehal wesam haitham alsharafi 
    // ameen almansoub abdullah aljabrie saeed alkuraite 
    // marwa alharadi nsreen alkuraet asmaa ali 
    
    public void add();
    
    public void update();
     
    public void delete();
    
    public String getAutoNumber();
    
    public void getAllRows(JTable table);
    
    public void getOneRow(JTable table);
    
    public void getCustomRows(String stmt , JTable table);
    
    /// take name and return id 
    public String getValueByName (String name);
    
    /// take id and return name 
    public String getNameByValue (String value);
}
