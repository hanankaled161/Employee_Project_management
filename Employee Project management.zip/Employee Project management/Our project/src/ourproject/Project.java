/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ourproject;

import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author WD
 */
public class Project  implements MainData {
    private int project;
    private int projectno;
    private  String projectname;
    private   String location;
    private  int deptno;

    public int getProjectno() {
        return projectno;
    }

    public void setProjectno(int projectno) {
        this.projectno = projectno;
    }

    public String getProjectname() {
        return projectname;
    }

    public void setProjectname(String projectname) {
        this.projectname = projectname;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getDeptno() {
        return deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    @Override
    public void add() {
        try{
        String insert = "insert into project values("
                +projectno+","
                +"'"+projectname+"',"
                +"'"+location+"',"
                +deptno+")";
//        "insert into project values("
//                +projectno+","
//                +"'"+projectname+"',"
//                +"'"+location+"',"
//                +deptno+")";
        
        
        
        
        
        
        
        boolean isAdd =Go.runNonQuery(insert);
        if (isAdd){
            JOptionPane.showMessageDialog(null, "project is added ");
        }}
        catch(Exception ex ){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
       
    }

    @Override
    public void update() {
        String update = "update project set "
                +"projectname ='"+projectname+"',"
                + "location ='"+location+"',"
                +"deptno ="+deptno
                +" where projectno="+projectno;
        
        boolean isUpdate = Go.runNonQuery(update);
        if (isUpdate){
            JOptionPane.showMessageDialog(null,"project is Updated ");
        }
    }

    @Override
    public void delete() {
        String delete = "delete from project where projectno ="+projectno;
        boolean isDel =Go.runNonQuery( delete);
        if (isDel){
            JOptionPane.showMessageDialog(null, "project is deleted ");
        }
    }

    @Override
    public String getAutoNumber() {
        return Go.getAutoNumber("project", "projectno");
    }

    @Override
    public void getAllRows(JTable table) {
       Go.fillToJTable("project", table);
    }

    @Override
    public void getOneRow(JTable table) {
        String strSelect = "select * from project where "+
                "projectno ="+projectno;
        Go.fillToJTable(strSelect, table);
    }

    @Override
    public void getCustomRows(String stmt, JTable table) {
        Go.fillToJTable(stmt, table);
    }
    

    @Override
    public String getValueByName(String name) {
       
               String strselect = "select projectno from project "
                +"where projectname ='"+name+"'";
        
        String strVal = 
                Go.getTableData(strselect).Items[0][0].toString();
        
        return strVal;
    }

    @Override
    public String getNameByValue(String value) {
        String strSelect = "select projectname from project "
                +"where projectno="+value;
        String strName = Go.getTableData(strSelect).Items[0][0].toString();
        
        return strName;
    }
    
    
}
