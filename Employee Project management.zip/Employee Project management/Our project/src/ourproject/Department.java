package ourproject;


import javax.swing.JOptionPane;
import javax.swing.JTable;
import ourproject.Go;
import ourproject.MainData;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WD
 */
public class Department implements MainData{
    int deptno ;
    String deptname;
    String location;

    public int getDeptno() {
        return deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    

    @Override
    public void add() {
        
        String strinsert = "insert into department values("+deptno+",'"+deptname+"','"+location+"')";
        
        boolean isAdd = Go.runNonQuery(strinsert);
        if(isAdd){
            JOptionPane.showMessageDialog(null, "employee is added successfuly ");
        }
    }

    @Override
    public void update() {
           String update = "update department set "
                +"deptname='"+deptname+"',"
                +"location='"+location+"' "
                +" where deptno = "+deptno;
        // if there is error add ; to the query 
        
         boolean isAdd = Go.runNonQuery(update);
        
        if (isAdd){
            JOptionPane.showMessageDialog(null,"Department is updated ");
        }
    }

    @Override
    public void delete() {
           String delete = "delete from department "+
                " where deptno ="+deptno;
         boolean isAdd = Go.runNonQuery(delete);
        
        if (isAdd){
            JOptionPane.showMessageDialog(null,"Department is deleted ");
        }
    }

    @Override
    public String getAutoNumber() {
               return Go.getAutoNumber("department","deptno");

    }
    @Override
    public void getAllRows(JTable table) {
           Go.fillToJTable("department", table);

    }

    @Override
    public void getOneRow(JTable table) {
          String strSelect = "select * from department "
                +"where deptno ="+deptno;
        Go.fillToJTable(strSelect, table); 
    }

    @Override
    public void getCustomRows(String stmt, JTable table) {
        Go.fillToJTable(stmt, table);
    }

    @Override
    public String getValueByName(String name) {
         String strSelect = "select deptno from department "
                +"where deptname = '"+name+"'";
        String strVal = (String)Go.getTableData(strSelect).Items[0][0];
        return strVal;
    }

    @Override
    public String getNameByValue(String value) {
             String strSelect = "select deptname from department where deptno = "+value;
        String strName;
        strName = (String)Go.getTableData(strSelect).Items[0][0];
        return strName;
    }
    
    
}
