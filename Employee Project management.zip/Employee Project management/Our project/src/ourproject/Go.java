
package ourproject;

// to make dealing with data more easier 


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
// I am listening for fairuz 
// JDBC java database  conectivety , connect between java and mySQL
// Good Morning , America 
// There is something missing in my heart 
////// // / // / // / // // / / / / / / /// / / / / / / / / / / 
// 2:33
public class Go {
    private static String myurl="jdbc:mysql://localhost:3306/ourproject?useUnicode=true&characterEncoding=UTF-8";
    private static Connection mycon ;
    //private static String DBname="company";
    
    // this method will repair the url 
    private static void setURL(){
        // jdbc is my driver 
        myurl = "jdbc:mysql://localhost:3306/ourproject?useUnicode=true&characterEncoding=UTF-8";
            //    myurl = "jdbc:mysql://localhost:3306/ourproject";

///last part to make arabic language acceptable
    }
    
    // method to control con variable 
    private static void setConnection(){
        try {
            setURL();
            mycon = DriverManager.getConnection(myurl,"root","");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage()+"didn't connect to database");
        }
    }
    
    public static void main (String[] args ){
        //this method is just for testing  
        // tobana tob tobana tob tobana tobana tobana tob 
        // x y x y x x x y 
        // x = tobana , y = tob ;
        
        String s = "select * from department ";
        JOptionPane.showMessageDialog(null,getTableData(s).Items[0][0]);
    }
    public static boolean runNonQuery(String sqlstmt){ // 
        try {
            setConnection();  //فتح الاتصال 
            Statement stmt = mycon.createStatement();
            stmt.execute(sqlstmt); 
            mycon.close();
            return true;    
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            return false ;
        }
    }
    
    public static String getAutoNumber(String tableName,String columnName){
        try {
            setConnection();
            Statement stmt = mycon.createStatement ();
            String strAuto = "select max("+columnName+")+1 as autonum"+
                    " from "+tableName;
            stmt.executeQuery(strAuto);
            String Num ="";
            while (stmt.getResultSet().next()){
                Num = stmt.getResultSet().getString("autonum");  // 4
            }
            mycon.close();
            if (Num == null || "".equals(Num)){
                return "1";
            }
            else {
                return Num;
            }
        }
        catch (SQLException jkjk){
            JOptionPane.showMessageDialog(null,jkjk.getMessage());
            return "0";
        } 
    }

    public static MyTable getTableData (String statement){
       try {
            setConnection();
            Statement stmt = mycon.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery(statement);
            
            ResultSetMetaData rsmd = rs.getMetaData(); // to deal easily with columns and every thing 
            int c = rsmd.getColumnCount();
            MyTable table = new MyTable (c);
            //while dealing with rows and the inside for will deal with columns
            while (rs.next()){
                Object row[] = new Object [c];
                for(int i=0;i<c;i++){
                    row[i]=rs.getString(i+1);  
                }
                table.addNewRow(row);
                
            }  
            mycon.close();
            return table;
        } 
        catch (SQLException eff){
            JOptionPane.showMessageDialog(null,eff.getMessage());
            MyTable nestedtable = new MyTable(0);
            return nestedtable;
        }
        
    } 
    // this method to put the data inside the combo box 
    public static void fillCombo (String tableName, String columnName, JComboBox combo){
        try {
            setConnection();
            Statement stmt = mycon.createStatement();
            ResultSet rs;
             
            String strSelect = "select "+columnName +" from "+tableName;
            rs= stmt.executeQuery(strSelect);
            rs.last(); //بدونهابيكون عدد البيانات صفر 
            int c = rs.getRow();
            rs.beforeFirst(); // عشان يرجع مكانه 
            String values[]= new String [c];
            int i =0;
            while (rs.next()){
                values[i] = rs.getString(1);
                i++;
            }
            
            mycon.close();

            combo.setModel(new DefaultComboBoxModel(values));
          
        }
        catch (SQLException jjj ){
            JOptionPane.showMessageDialog(null,jjj.getMessage());
        }
    }
    
    public static void fillToJTable(String tableNameOrSelectStatement,JTable table){
        try {
            setConnection();
            Statement stmt = mycon.createStatement();
            
            ResultSet rs ;
            String SPart=tableNameOrSelectStatement.substring(0,7).toLowerCase();
            String strSelect ;
            
            if ("select ".equals(SPart)){ // this if it is select statemnt 
                strSelect = tableNameOrSelectStatement;
            }
            else {
                // this if it is table name
                strSelect = "select * from "+tableNameOrSelectStatement;
            }
            
            rs=stmt.executeQuery(strSelect);
            ResultSetMetaData rsmd = rs.getMetaData();
            int c = rsmd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Vector row = new Vector(); // 
            model.setRowCount(0);
            
            while (rs.next()){
                row = new Vector(c);
                for (int i =1;i<c+1;i++){  // here i add +1
                row.add(rs.getString(i)); // fill the JTable
            }
                model.addRow(row);
            }
            
            if (table.getColumnCount() != c){
                JOptionPane.showMessageDialog(null,"JTable Columns count not equal to query columns count ");
                
            }
            mycon.close();
        }
        catch (SQLException ghgh){
            JOptionPane.showMessageDialog(null, ghgh.getMessage());
        }
    }
    

    
    
}