
package ourproject;

public class MyTable {
    public int columns ;
    public Object[][] Items;
    public MyTable (int columns){
        this.columns= columns;
        Items= new Object[0][columns];
    }
        
    public MyTable ( ){
       // Items= new Object[0][columns];
    }
    
    public void addNewRow (Object row[]){
        // save the previous data in a temp variable 
        Object TempItems[][]= Items;
        Items = new Object [Items.length+1][columns];
         for (int i =0;i<TempItems.length;i++){
             
            Items [i]= TempItems[i];
         }
         Items[Items.length-1] = row; 
       
    }
    
    public void printItems (){
        for(Object[] objs :Items){
            for (Object obj :objs){
                System.out.print(obj+" ; ");
            }
        }
    }
 
    public void editRow(int rowIndex, int columnIndex,Object newData){
        
        Items[rowIndex][columnIndex]= newData;
          
    }
    
    public void deleteRow(int rowIndex){
        Object TempItems [][] = Items;
        Items = new Object [Items.length -1 ][columns];
        int y=0;
        for (int x = 0;x<TempItems.length ;x++){
            if (x != rowIndex){
                Items[y]= TempItems[x];
                y++;
            }
        }
    }
    public Object getValue(int rowIndex, int columnIndex){
        return Items[rowIndex][columnIndex];
    }
    
    public Object[] getRow(int rowIndex){
        return Items[rowIndex];
    }
}
