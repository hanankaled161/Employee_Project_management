
package ourproject;

import javax.swing.JOptionPane;
import javax.swing.JTable;

/// this class will be different from the other classes 
// you should focus on it while studing 
public class Workon implements MainData{
    private int empno;
    private int projectno;

    public int getEmpno() {
        return empno;
    }

    public void setEmpno(int empno) {
        this.empno = empno;
    }

    public int getProjectno() {
        return projectno;
    }

    public void setProjectno(int projectno) {
        this.projectno = projectno;
    }

    @Override
    public void add() {
        String insert = "insert into workon values("
                +empno+","+projectno
                +")";
        
        boolean isAdd = Go.runNonQuery(insert);
        if (isAdd){
            JOptionPane.showMessageDialog(null, "workon is added successfully ");
        }
    }

    @Override
    public void update() {
        
        JOptionPane.showMessageDialog(null, "update method doesn't work on workon class ");
    }
    

    @Override
    public void delete() {
        try {
        String delete = "delete from workon where empno="+empno+" and projectno ="+projectno;
        
        boolean isdelete =Go.runNonQuery(delete);
        if (isdelete){
            JOptionPane.showMessageDialog(null, "workon is deleted ");
        }}
        catch (Exception ex){
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
    }

    @Override
    public String getAutoNumber() {
        JOptionPane.showMessageDialog(null, "getAutonumber method doesn't work on workon class ");
        return "";
    }

    @Override
    public void getAllRows(JTable table) {
        Go.fillToJTable("workon", table);
    }
    

    @Override
    public void getOneRow(JTable table) {
        String strselect = "select * from workon where "
                +"empno ="+empno+
                " and "+"projectno="+projectno;
        Go.fillToJTable(strselect, table);
    }

    @Override
    public void getCustomRows(String stmt, JTable table) {
        Go.fillToJTable(stmt, table);
    }

    @Override
    public String getValueByName(String name) {
        JOptionPane.showMessageDialog(null, "getValueByName method doesn't work on workon class ");
        return "";
    }

    @Override
    public String getNameByValue(String value) {
        JOptionPane.showMessageDialog(null, "getNameByValue method doesn't work on workon class ");
        return "";    }
    
    
}
