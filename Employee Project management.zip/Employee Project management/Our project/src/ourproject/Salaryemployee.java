/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ourproject;

import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author WD
 */
public class Salaryemployee extends Employee implements MainData {
    String vacations;

    public Salaryemployee(int empno, String empname, String birthdate, double salary, String hiringdate, String emptype, String vacations, Address addr, int deptno) {
        super(empno, empname, birthdate, salary, hiringdate, emptype, addr, deptno);
        this.vacations=vacations;
    }

   
     @Override
    public void add() {
    String strinsert = "insert into employees values (" +empno+",'"+empname+"','"+birthdate+"','"+salary+"','"+hiringdate+"','"
            +emptype+"','"+vacations+"','"+addr+"',"+deptno+");";
              
            
           
        // here add semicolon if it is wrong 

        boolean isAdd = Go.runNonQuery(strinsert);
        
        if (isAdd){
            JOptionPane.showMessageDialog(null,"employees is Added ");
        }    }
    @Override
    public void update() {
        String strinsert = "update employees set "
                +"empname='"+empname+"',"
                +"birthdate='"+birthdate+"' ,"
                +"salary="+salary+" "
                +" ,hiringdate='"+hiringdate+"' , "
                +"emptype='"+emptype+"', "
                +"address='"+addr+"' , "
                +"vacations='"+vacations+"' "
                +" where empno = "+empno;
              
            
           
        // here add semicolon if it is wrong 

        boolean isUpdate = Go.runNonQuery(strinsert);
        
        if (isUpdate){
            JOptionPane.showMessageDialog(null,"employees is Updated ");
        } 
    }

    public String getVacations() {
        return vacations;
    }

    public void setVacations(String vacations) {
        this.vacations = vacations;
    }

    public int getEmpno() {
        return empno;
    }

    public void setEmpno(int empno) {
        this.empno = empno;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getHiringdate() {
        return hiringdate;
    }

    public void setHiringdate(String hiringdate) {
        this.hiringdate = hiringdate;
    }

    public String getEmptype() {
        return emptype;
    }

    public void setEmptype(String emptype) {
        this.emptype = emptype;
    }

    public Address getAddr() {
        return addr;
    }

    public void setAddr(Address addr) {
        this.addr = addr;
    }

    public int getDeptno() {
        return deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    @Override
    public void delete() {
    String delete = "delete from employees "+
                " where empno ="+empno;
         boolean isDel = Go.runNonQuery(delete);
        
        if (isDel){
            JOptionPane.showMessageDialog(null,"employees is deleted ");
        }    }

    @Override
    public String getAutoNumber() {
               return Go.getAutoNumber("employees","empno");
    }

    @Override
    public void getAllRows(JTable table) {
           Go.fillToJTable("employees", table);
    }

    @Override
    public void getOneRow(JTable table) {
      String strSelect = "select * from employees "
                +"where empno ="+empno;
        Go.fillToJTable(strSelect, table);     }

    @Override
    public void getCustomRows(String stmt, JTable table) {
        Go.fillToJTable(stmt, table);
    }

    @Override
    public String getValueByName(String name) {
     String strSelect = "select empno from employees "
                +"where empname = '"+name+"'";
        String strVal = (String)Go.getTableData(strSelect).Items[0][0];
        return strVal;    }

    @Override
    public String getNameByValue(String value) {
     String strSelect = "select empname from employees where empno = "+value;
        String strName;
        strName = (String)Go.getTableData(strSelect).Items[0][0];
        return strName;  }
}
